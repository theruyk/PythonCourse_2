# Вспомните какие модули вы уже проходили на курсе.
# Создайте файл, в котором вы импортируете встроенные # в модуль функции под дсевдонимами. (3-7 строк импорте).
from fractions import Fraction as Frc
from math import factorial as fc, copysign as os, isfinite as i_f
print (fc (56))