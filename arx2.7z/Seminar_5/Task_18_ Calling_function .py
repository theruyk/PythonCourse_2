"""Вызов функции из файла Task_17_creating_modul """

from Task_17_creating_modul import func

print (func(1, 50, 10))