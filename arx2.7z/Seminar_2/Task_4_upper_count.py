print("Hello world!".upper())
print ("Hello world!".count('l'))