import random
import pytest
import string
from checkers import checkout, getout

# Это пути к папкам, которые используются в тестах
folder_in = "/home/zerg/tst"
folder_out = "/home/zerg/out"
folder_ext = "/home/zerg/folder1"
folder_ext2 = "/home/zerg/folder2"

# Фикстура pytest для создания папок перед выполнением тестов
@pytest.fixture()
def make_folders():
    # Использует функцию checkout для выполнения команды mkdir и создания папок
    return checkout(f"mkdir {folder_in} {folder_out} {folder_ext} {folder_ext2}", "")

# Фикстура pytest для создания тестовых файлов
@pytest.fixture()
def make_files():
    list_of_files = []
    # Генерируем 5 случайных имен файлов и создаем их с помощью команды dd
    for i in range(5):
        filename = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
        if checkout(f"cd {folder_in}; dd if=/dev/urandom of={filename} bs=1M count=1 iflag=fullblock", ""):
            list_of_files.append(filename)
    return list_of_files

# Фикстура pytest для создания подпапок
@pytest.fixture()
def make_subfolder():
    # Генерируем случайное имя для тестового файла и подпапки
    testfilename = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
    subfoldername = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
    # Создаем подпапку
    if not checkout(f"cd {folder_in}; mkdir {subfoldername}", ""):
        return None, None
    # Создаем тестовый файл
    if not checkout(f"cd {folder_in}/{subfoldername}; dd if=/dev/urandom of={testfilename} bs=1M count=1 iflag=fullblock", ""):
        return subfoldername, None
    else:
        return subfoldername, testfilename

def test_step1(make_folders, clear_folders, make_files):
    # Тест 1: Создание архива из содержимого папки folder_in.
    res1 = checkout("cd {}; 7z a {}/arx2".format(folder_in, folder_out), "Everything is Ok")
    res2 = checkout("ls {}".format(folder_out), "arx2.7z")
    assert res1 and res2, "test1 FAIL"

def test_step2(clear_folders, make_files):
    # Тест 2: Проверка наличия файлов внутри архива arx2.7z.
    res = []
    res.append(checkout("cd {}; 7z a {}/arx2".format(folder_in, folder_out), "Everything is Ok"))
    res.append(checkout("cd {}; 7z e arx2.7z -o{} -y".format(folder_out, folder_ext), "Everything is Ok"))
    for item in make_files:
        res.append(checkout("ls {}".format(folder_ext), item))
    assert all(res), "test2 FAIL"

def test_step3():
    # Тест 3: Проверка целостности архива
    assert checkout(f"cd {folder_out}; 7z t arx2.7z", "Everything is Ok"), "test3 FAIL"

def test_step4():
    # Тест 4: Проверка обновления содержимого архива
    assert checkout(f"cd {folder_in}; 7z u arx2.7z", "Everything is Ok"), "test4 FAIL"

def test_step5(clear_folders, make_files):
    # Тест 5: Проверка создания архива и его содержимого
    res = []
    # Создает архив и проверяет, было ли это успешно
    res.append(checkout(f"cd {folder_in}; 7z a {folder_out}/arx2", "Everything is Ok"))
    # Проверяет наличие каждого файла из списка make_files в архиве arx2.7z
    for item in make_files:
        res.append(checkout(f"cd {folder_out}; 7z l arx2.7z", item))
    # Проверяет, что все предыдущие действия прошли успешно
    assert all(res), "test5 FAIL"

def test_step6(clear_folders, make_files, make_subfolder):
    # Тест 6: Проверка содержимого архива и извлечения файлов
    res = []
    # Создает архив и проверяет, было ли это успешно
    res.append(checkout(f"cd {folder_in}; 7z a {folder_out}/arx", "Everything is Ok"))
    # Извлекает содержимое архива и проверяет, было ли это успешно
    res.append(checkout(f"cd {folder_out}; 7z x arx.7z -o{folder_ext2} -y", "Everything is Ok"))
    # Проверяет наличие каждого файла из списка make_files в извлеченной папке folder_ext2
    for item in make_files:
        res.append(checkout(f"ls {folder_ext2}", item))
    # Проверяет, что все предыдущие действия прошли успешно
    assert all(res), "test6 FAIL"

def test_step7():
    # Тест 7: Проверка удаления содержимого архива
    assert checkout(f"cd {folder_out}; 7z d arx.7z", "Everything is Ok"), "test7 FAIL"

def test_step8(clear_folders, make_files):
    # Тест 8: Проверка расчета хеша файлов и сравнение с выводом команды crc32
    res = []
    for item in make_files:
        # Выполняет команду для расчета хеша файла с помощью 7z и добавляет результат в список res
        res.append(checkout(f"cd {folder_in}; 7z h {item}", "Everything is Ok"))
        # Вызывает команду crc32 для расчета хеша и преобразует вывод в верхний регистр
        hash = getout(f"cd {folder_in}; crc32 {item}").upper()
        # Выполняет команду для проверки хеша файла с помощью 7z и добавляет результат в список res
        res.append(checkout(f"cd {folder_in}; 7z h {item}", hash))
    # Проверяет, все ли результаты в res истинны (True)
    assert all(res), "test8 FAIL"

#pytest -vv /Users/the_ryuk/Desktop/PythonCurse_2/Progect_linux_curse/progect.py