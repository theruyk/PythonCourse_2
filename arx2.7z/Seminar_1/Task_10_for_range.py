
num = int (input ('Введите число: '))
for i in range(0, num, 2): #(0 - стартовое число, num - конечное, 2 - шаг)
  print(i)