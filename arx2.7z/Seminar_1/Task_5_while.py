num = float(input('Введите число: '))
count = 0
while count < num:
  print(count)
  count += 2
