"""ord (char)"""
print(ord('a'))
print(ord('а'))
print (ord('😇'))