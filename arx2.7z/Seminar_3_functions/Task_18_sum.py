"""sum (iterable, /, start=0)"""
my_list = [42, 256, 73]
print (sum (my_list))
print (sum(my_list, start=1024))