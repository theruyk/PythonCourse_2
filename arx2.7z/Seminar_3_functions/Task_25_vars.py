"""vars (object)"""

print (vars(int))