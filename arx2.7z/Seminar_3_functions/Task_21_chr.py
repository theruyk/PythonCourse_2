"""chr (integer)"""

print(chr(97))
print(chr(1105))
print (chr(128519))