a = b = c = 0 # Хорошо 
a += 42
print(f'{a=} {b=} {c=}')


a = b = с = {1, 2, 3} # Плохо
a.add (42)
print (f'{a=} {b=} {c=}')