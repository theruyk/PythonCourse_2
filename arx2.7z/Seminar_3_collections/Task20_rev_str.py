# реверс строки

text = 'Hello world!'
print (text[::-1])