text = 'однажды в СТУДЁНУЮ ЗИМНЮЮ ПоРУ'
print(text.upper())
print (text.lower())
print(text.title())
print(text.capitalize())