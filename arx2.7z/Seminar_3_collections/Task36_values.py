# Итерация по значению

my_dict = {'one': 1, 'two': 2,'three': 3, 'four': 4, 'ten': 10}
print (my_dict.values())
for value in my_dict.values():
  print(value)
