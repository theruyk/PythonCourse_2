my_set = {3, 4, 2, 5, 6, 1, 7}
print (42 in my_set)