# Сортирует текущий список, не создавая новый
my_list = [4, 8, 2, 9, 1, 7, 2]
my_list.sort()
print (my_list)
my_list.sort (reverse=True) # реверсирует текущих список
print (my_list)