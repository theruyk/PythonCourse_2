name = 'Alex'
age = 12
text = 'Меня зовут {} и мне {} лет'. format(name, age)
print(text)