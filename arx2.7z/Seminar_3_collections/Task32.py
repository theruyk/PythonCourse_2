# Получение значения по ключу

TEN = 'ten'
my_dict = {'one': 1, 'two': 2, 'three': 3, 'four': 4, 'ten': 10}

print (my_dict[ 'two' ])
print (my_dict [TEN])
#print (my_dict[1]) # KeyError: 1