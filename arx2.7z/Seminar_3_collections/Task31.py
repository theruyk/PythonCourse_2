# добавление элемента в словарь
my_dict = {'one': 1, 'two': 2, 'three': 3, 'four': 4}
X = 10
my_dict['ten'] = X
print (my_dict) 