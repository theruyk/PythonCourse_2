import os
from pathlib import Path

os.mkdir ('new_os_dir')
Path ('new_path_dir').mkdir ()