with open ('text_data.txt', 'r', encoding='utf-8') as f:
  print(list(f))
