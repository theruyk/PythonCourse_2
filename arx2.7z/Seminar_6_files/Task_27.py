import os
from pathlib import Path

os.rmdir('dir/other_dir/new_os_dir')# удаление директории
Path ('some_dir/dir/new_path_dir').rmdir()