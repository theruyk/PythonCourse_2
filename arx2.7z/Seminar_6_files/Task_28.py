"""Добавляем файлы в каталоги для демонстрации"""
# import shutil
# shutil.rmtree('dir/other_dir') # Удалит все дерево с файлами внутри
# shutil.rmtree('some_dir')